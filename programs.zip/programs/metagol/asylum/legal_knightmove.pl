
true.

legal_knightmove(A,B,C,D,E,F):-false.
