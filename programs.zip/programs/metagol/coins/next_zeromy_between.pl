
true.

next_zeromy_between(A,B,C):-false.
