
true.

% learning next_strength/3
% clauses: 1
% clauses: 2
% clauses: 3
