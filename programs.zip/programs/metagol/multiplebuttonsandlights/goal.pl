
true.

% learning goal/3
% clauses: 1
goal(A,B,0):-not_my_index(A,B).
