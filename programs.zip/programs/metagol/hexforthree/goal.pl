
true.

% learning goal/3
% clauses: 1
% clauses: 2
