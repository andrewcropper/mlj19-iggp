
true.

% learning next_cell/4
% clauses: 1
% clauses: 2
