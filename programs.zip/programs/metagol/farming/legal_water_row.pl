
true.

% learning legal_water_row/3
% clauses: 1
% clauses: 2
