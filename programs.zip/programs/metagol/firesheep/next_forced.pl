
true.

% learning next_forced/2
% clauses: 1
% clauses: 2
next_forced(A,B):-next_forced_1(A,B,C).
next_forced_1(A,B,C):-does_force_noop(A,C,B).
