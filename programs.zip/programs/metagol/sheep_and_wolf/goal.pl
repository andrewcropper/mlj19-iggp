
true.

% learning goal/3
% clauses: 1
% clauses: 2
goal(A,wolf,100).
goal(A,sheep,0).
