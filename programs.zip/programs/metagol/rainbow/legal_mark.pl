
true.

% learning legal_mark/4
% clauses: 1
% clauses: 2
legal_mark(A,B,C,D):-legal_mark_1(A,B,C,E),not_my_input_mark(A,B,D,E).
legal_mark_1(A,B,C,D):-not_hue(A,B),not_my_true_color(A,C,D).
