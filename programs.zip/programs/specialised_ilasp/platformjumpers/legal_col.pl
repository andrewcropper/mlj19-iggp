
legal_col(V0, V1) :- not true_coled(V1), agent(V0), pos(V1).
