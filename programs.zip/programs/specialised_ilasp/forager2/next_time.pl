
next_time(V0) :- succ(V0, V5), true_time(V5), int(V0), int(V5).
