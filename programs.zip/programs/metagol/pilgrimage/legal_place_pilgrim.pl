
true.

% learning legal_place_pilgrim/4
% clauses: 1
% clauses: 2
% clauses: 3
