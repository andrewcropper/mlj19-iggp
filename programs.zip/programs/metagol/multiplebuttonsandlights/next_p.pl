
true.

% learning next_p/2
% clauses: 1
% clauses: 2
% clauses: 3
