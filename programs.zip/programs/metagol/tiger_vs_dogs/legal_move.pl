
true.

% learning legal_move/6
% clauses: 1
% clauses: 2
% clauses: 3
