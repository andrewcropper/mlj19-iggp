
true.

% learning legal_jump/4
% clauses: 1
% clauses: 2
% clauses: 3
% clauses: 4
