
true.

% learning next_open/3
% clauses: 1
% clauses: 2
% clauses: 3
