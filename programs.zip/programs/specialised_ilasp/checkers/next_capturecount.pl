
next_capturecount(V0, V1) :- true_capturecount(V0, V1), agent(V0), pos(V1), int(V1).
