
true.

% learning next_season/2
% clauses: 1
% clauses: 2
