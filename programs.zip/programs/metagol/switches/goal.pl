
true.

goal(A,B,C):-false.
