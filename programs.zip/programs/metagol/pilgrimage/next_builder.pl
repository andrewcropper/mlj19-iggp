
true.

% learning next_builder/4
% clauses: 1
% clauses: 2
