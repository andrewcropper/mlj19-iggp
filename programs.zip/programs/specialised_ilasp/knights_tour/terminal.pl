
terminal :- true_cell(V10, V14, V53), true_cell(V32, V10, V53), V10 = 4, pos(V10), int(V10), pos(V14), int(V14), pos(V32), int(V32), mark(V53).
