
goal(V0, V1) :- scoreMap(V6, V1), true_moveCount(V6), agent(V0), int(V1), int(V6).
