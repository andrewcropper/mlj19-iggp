
true.

% learning next_grass/4
% clauses: 1
% clauses: 2
