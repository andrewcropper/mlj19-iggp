
true.

% learning next_cell/5
% clauses: 1
% clauses: 2
% clauses: 3
