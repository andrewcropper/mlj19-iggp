
true.

% learning next_marked/3
% clauses: 1
% clauses: 2
% clauses: 3
next_marked(A,B,C):-my_true_at(A,B,C,x).
next_marked(A,B,C):-my_true_at(A,B,C,o).
next_marked(A,B,C):-my_true_marked(A,B,C).
