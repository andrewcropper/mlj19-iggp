
true.

% learning terminal/1
% clauses: 1
% clauses: 2
