
true.

legal_kingmove(A,B,C,D,E,F):-false.
