
true.

next_onemy_between(A,B,C):-false.
