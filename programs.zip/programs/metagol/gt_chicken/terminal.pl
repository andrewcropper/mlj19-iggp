
true.

% learning terminal/1
% clauses: 1
terminal(A):-maxRounds(A,B),my_true_rounds(A,B).
