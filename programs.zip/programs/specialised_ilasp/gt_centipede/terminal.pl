
terminal :- true_gameOver.
