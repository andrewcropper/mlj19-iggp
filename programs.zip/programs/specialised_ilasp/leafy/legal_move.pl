
legal_move(V0, V1, V2) :- close(V4, V2), true_leaf(V1, V2), true_isplayer(V1, V4, V0), agent(V0), pos(V1), pos(V2), pos(V4).
legal_move(V0, V1, V2) :- close(V9, V1), true_leaf(V1, V2), true_isplayer(V9, V2, V0), agent(V0), pos(V1), pos(V2), pos(V9).
