
true.

% learning next_ripe/4
% clauses: 1
% clauses: 2
