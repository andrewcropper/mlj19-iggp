
next_correctToads(V0) :- true_correctToads(V0), does_jump(V117, V46, V79, V68, V79), int(V0), pos(V46), int(V46), pos(V68), int(V68), pos(V79), int(V79), agent(V117).
next_correctToads(V0) :- succ(V79, V68), does_jump(V117, V68, V57, V68, V79), V0 = 1, pos(V0), int(V0), pos(V57), int(V57), pos(V68), int(V68), pos(V79), int(V79), agent(V117).
next_correctToads(V0) :- succ(V68, V57), true_correctToads(V0), true_cell(V57, V116, V118), does_move(V117, V90, V68, V116, V68), int(V0), pos(V57), int(V57), pos(V68), int(V68), pos(V90), int(V90), pos(V116), int(V116), agent(V117), object(V118).
next_correctToads(V0) :- true_correctToads(V0), does_move(V117, V46, V79, V46, V68), int(V0), pos(V46), int(V46), pos(V68), int(V68), pos(V79), int(V79), agent(V117).
next_correctToads(V0) :- true_correctFrogs(V0), does_move(V117, V68, V68, V57, V68), pos(V0), int(V0), pos(V57), int(V57), pos(V68), int(V68), agent(V117).
next_correctToads(V0) :- succ(V46, V35), true_correctFrogs(V0), true_cell(V68, V46, V120), true_cell(V79, V57, V120), does_jump(V117, V68, V57, V68, V35), int(V0), pos(V35), int(V35), pos(V46), int(V46), pos(V57), int(V57), pos(V68), int(V68), pos(V79), int(V79), agent(V117), object(V120).
