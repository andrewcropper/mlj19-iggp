
true.

% learning goal/3
% clauses: 1
goal(A,B,C):-my_true_strength(A,B,D),scoremap(A,D,C).
