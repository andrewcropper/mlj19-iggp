
goal(V0, V1) :- true_step(V18), true_cell(V25, V0), V1 = 100, V18 = 13, V25 = c, agent(V0), mark(V0), int(V1), int(V18), pos(V25).
goal(V0, V1) :- true_cell(V24, V22), V1 = 0, V24 = d, agent(V0), mark(V0), int(V1), agent(V22), mark(V22), pos(V24).
goal(V0, V1) :- true_cell(V26, V0), V1 = 0, V26 = b, agent(V0), mark(V0), int(V1), pos(V26).
goal(V0, V1) :- true_cell(V27, V0), V1 = 0, V27 = a, agent(V0), mark(V0), int(V1), pos(V27).
goal(V0, V1) :- true_step(V19), true_cell(V25, V0), V1 = 100, V19 = 12, V25 = c, agent(V0), mark(V0), int(V1), int(V19), pos(V25).
