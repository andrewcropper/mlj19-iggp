
true.

% learning legal_choose/3
% clauses: 1
legal_choose(A,B,C):-not_my_succ(A,B,C).
