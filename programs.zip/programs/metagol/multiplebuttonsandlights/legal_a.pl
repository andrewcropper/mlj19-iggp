
true.

% learning legal_a/3
% clauses: 1
legal_a(A,B,C):-my_input_a(A,B,C).
