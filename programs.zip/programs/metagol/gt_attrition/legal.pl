
true.

% learning legal/3
% clauses: 1
% clauses: 2
% clauses: 3
legal(A,B,noop):-not_my_true_control(A,B).
legal(A,B,lay_claim):-my_true_control(A,B).
legal(A,B,end_game):-my_true_control(A,B).
