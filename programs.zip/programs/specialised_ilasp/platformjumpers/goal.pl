
goal(V0, V1) :- V1 = 50, agent(V0), int(V1).
