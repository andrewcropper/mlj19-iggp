
true.

% learning legal_c/3
% clauses: 1
legal_c(A,B,C):-my_input_a(A,B,C).
