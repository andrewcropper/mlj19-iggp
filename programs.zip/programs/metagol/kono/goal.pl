
true.

% learning goal/3
% clauses: 1
goal(A,B,C):-my_true_score(A,B,C).
