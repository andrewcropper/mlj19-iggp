
true.

% learning next_grass_last_turn/2
% clauses: 1
% clauses: 2
