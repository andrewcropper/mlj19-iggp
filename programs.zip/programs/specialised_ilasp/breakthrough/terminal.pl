
terminal :- true_cell(V1, V3, V9), not true_control(V9), V3 = 5, int(V1), int(V3), agent(V9).
