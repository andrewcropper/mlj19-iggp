
next_jumper(V0, V1, V2) :- board_succ_two(V2, V5), agent(V0), pos(V1), pos(V2), pos(V5).
next_jumper(V0, V1, V1) :- true_jumper(V0, V1, V1), agent(V0), pos(V1).
