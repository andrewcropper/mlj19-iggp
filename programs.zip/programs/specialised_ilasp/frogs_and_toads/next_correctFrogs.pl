
next_correctFrogs(V0) :- true_correctFrogs(V0), pos(V0), int(V0).
next_correctFrogs(V0) :- true_correctToads(V0), does_move(V117, V68, V68, V68, V57), pos(V0), int(V0), pos(V57), int(V57), pos(V68), int(V68), agent(V117).
next_correctFrogs(V0) :- true_step(V97), V0 = 1, V97 = 13, pos(V0), int(V0), int(V97).
next_correctFrogs(V0) :- succ(V90, V79), succ(V0, V90), true_cell(V68, V68, V119), true_cell(V90, V57, V119), does_jump(V117, V68, V79, V68, V57), pos(V0), int(V0), pos(V57), int(V57), pos(V68), int(V68), pos(V79), int(V79), pos(V90), int(V90), agent(V117), object(V119).
next_correctFrogs(V0) :- succ(V68, V57), succ(V79, V68), true_correctFrogs(V0), true_cell(V68, V57, V120), true_cell(V79, V68, V120), int(V0), pos(V57), int(V57), pos(V68), int(V68), pos(V79), int(V79), object(V120).
next_correctFrogs(V0) :- true_correctFrogs(V0), true_cell(V68, V68, V119), not true_step(V13), V13 = 10, V119 = frog, int(V0), int(V13), pos(V68), int(V68), object(V119).
next_correctFrogs(V0) :- true_step(V77), true_correctToads(V0), V77 = 31, int(V0), int(V77).
