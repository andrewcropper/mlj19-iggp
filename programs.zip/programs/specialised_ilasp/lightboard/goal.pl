
goal(V0, V1) :- successor(V8, V7), true_on(V7, V8), true_on(V8, V7), V1 = 100, V7 = 4, agent(V0), int(V1), pos(V7), int(V7), pos(V8), int(V8).
goal(V0, V1) :- true_step(V7), V1 = 0, agent(V0), int(V1), pos(V7), int(V7).
goal(V0, V1) :- true_on(V6, V2), V1 = 0, V2 = 8, agent(V0), int(V1), pos(V2), int(V2), pos(V6), int(V6).
goal(V0, V1) :- true_on(V2, V5), V1 = 0, V2 = 8, agent(V0), int(V1), pos(V2), int(V2), pos(V5), int(V5).
goal(V0, V1) :- true_on(V5, V9), V1 = 0, V9 = 2, agent(V0), int(V1), pos(V5), int(V5), pos(V9), int(V9).
