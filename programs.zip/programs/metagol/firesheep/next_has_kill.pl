
true.

% learning next_has_kill/2
% clauses: 1
next_has_kill(A,B):-my_true_has_kill(A,B),not_does_kill(A,B,C).
