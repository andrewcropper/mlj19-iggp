
next_target(V0, V1) :- true_target(V0, V1), pos(V0), pos(V1).
