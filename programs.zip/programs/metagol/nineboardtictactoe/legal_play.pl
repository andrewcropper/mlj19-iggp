
true.

% learning legal_play/7
% clauses: 1
% clauses: 2
% clauses: 3
% clauses: 4
