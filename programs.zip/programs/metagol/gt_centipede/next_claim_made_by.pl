
true.

next_claim_made_by(A,B):-false.
