
true.

% learning legal_force_noop/3
% clauses: 1
% clauses: 2
