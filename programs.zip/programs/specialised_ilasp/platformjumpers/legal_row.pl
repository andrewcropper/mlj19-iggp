
legal_row(V0, V1) :- not true_rowed(V1), agent(V0), pos(V1).
