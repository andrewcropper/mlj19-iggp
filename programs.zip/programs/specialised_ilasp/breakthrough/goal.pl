
goal(V0, V1) :- V1 = 0, agent(V0), score_type(V1).
