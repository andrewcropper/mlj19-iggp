
true.

% learning next_jumper/4
% clauses: 1
% clauses: 2
% clauses: 3
