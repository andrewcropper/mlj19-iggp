
terminal :- true_step(V12), V12 = 50, time_step(V12), score_int(V12).
