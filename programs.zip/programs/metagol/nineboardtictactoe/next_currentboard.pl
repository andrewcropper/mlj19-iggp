
true.

% learning next_currentboard/3
% clauses: 1
% clauses: 2
% clauses: 3
