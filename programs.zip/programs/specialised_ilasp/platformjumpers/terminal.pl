
terminal :- valid_move(V0, V5, V1, V6, V1), true_jumper(V0, V5, V6), agent(V0), pos(V1), pos(V5), pos(V6).
