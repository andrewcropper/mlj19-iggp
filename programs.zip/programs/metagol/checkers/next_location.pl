
true.

% learning next_location/4
% clauses: 1
% clauses: 2
