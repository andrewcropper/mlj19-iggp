
next_score(V0, V1) :- succ(V29, V28), true_score(V0, V29), V1 = 25, agent(V0), mark(V0), int(V1), int(V28), int(V29).
next_score(V0, V1) :- true_score(V0, V1), agent(V0), mark(V0), int(V1).
