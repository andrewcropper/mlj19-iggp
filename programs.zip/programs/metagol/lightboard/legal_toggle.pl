
true.

% learning legal_toggle/4
% clauses: 1
legal_toggle(A,B,C,D):-my_input_toggle(A,B,C,D).
