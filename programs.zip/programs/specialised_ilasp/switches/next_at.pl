
next_at(V0, V1, V2) :- true_at(V0, V1, V2), does(V6, V12), not dir(V12), pos(V0), pos(V1), obj(V2), agent(V6), action(V12).
next_at(V0, V1, V2) :- succ(V1, V5), player_obj(V2), true_at(V0, V5, V2), does(V6, V14), V14 = down, pos(V0), pos(V1), obj(V2), pos(V5), agent(V6), action(V14).
next_at(V0, V1, V2) :- succ(V4, V0), true_at(V0, V1, V2), not player_obj(V2), pos(V0), pos(V1), obj(V2), pos(V4).
next_at(V0, V1, V2) :- succ(V3, V1), player_obj(V2), true_at(V0, V3, V2), does(V6, V10), V10 = up, pos(V0), pos(V1), obj(V2), pos(V3), agent(V6), action(V10).
next_at(V0, V1, V2) :- succ(V4, V0), player_obj(V2), true_at(V4, V1, V2), does(V6, V11), V11 = right, pos(V0), pos(V1), obj(V2), pos(V4), agent(V6), action(V11).
next_at(V0, V1, V2) :- succ(V0, V4), player_obj(V2), true_at(V4, V1, V2), does(V6, V13), V13 = left, pos(V0), pos(V1), obj(V2), pos(V4), agent(V6), action(V13).
next_at(V0, V1, V2) :- succ(V0, V3), succ(V5, V4), true_switch(V1, V4, V9), true_open(V9, V0), true_at(V5, V3, V7), pos(V0), pos(V1), obj(V2), pos(V3), pos(V4), pos(V5), obj(V7), obj(V9).
next_at(V0, V1, V2) :- true_target(V4, V0), true_at(V1, V5, V7), true_at(V0, V1, V2), pos(V0), pos(V1), obj(V2), pos(V4), pos(V5), obj(V7).
next_at(V0, V1, V2) :- succ(V1, V3), is_box(V2), true_at(V3, V5, V8), true_at(V0, V1, V2), pos(V0), pos(V1), obj(V2), pos(V3), pos(V5), obj(V8).
