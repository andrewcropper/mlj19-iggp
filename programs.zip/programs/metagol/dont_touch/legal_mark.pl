
true.

% learning legal_mark/4
% clauses: 1
% clauses: 2
legal_mark(A,B,C,D):-my_true_control(A,B),legal_mark_1(A,C,D).
legal_mark_1(A,B,C):-my_true_cell(A,B,C,b).
