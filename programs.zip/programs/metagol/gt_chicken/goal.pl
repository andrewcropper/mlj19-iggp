
true.

% learning goal/3
% clauses: 1
% clauses: 2
goal(A,white,B):-my_true_whiteScore(A,B).
goal(A,black,B):-my_true_blackScore(A,B).
