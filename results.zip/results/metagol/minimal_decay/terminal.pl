true.

0,0
0,0
