
next_step(V0) :- succ(V6, V0), true_step(V6), pos(V0), pos(V6).
