
true.

% learning legal_b/3
% clauses: 1
legal_b(A,B,C):-my_input_a(A,B,C).
