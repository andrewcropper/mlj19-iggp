
true.

% learning legal/3
% clauses: 1
legal(A,B,C):-not_beats(A,B,C).
