
terminal :- maxRounds(V88), true_rounds(V88), int(V88).
