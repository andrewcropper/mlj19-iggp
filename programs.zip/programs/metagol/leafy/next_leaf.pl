
true.

% learning next_leaf/3
% clauses: 1
% clauses: 2
next_leaf(A,B,C):-my_true_leaf(A,B,C),next_leaf_1(A,B,C).
next_leaf_1(A,B,C):-not_my_true_isplayer(A,B,C,D).
