
terminal :- true_capturecount(V24, V16), not index(V16), int(V16), agent(V24).
