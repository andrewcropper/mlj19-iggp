
next_connected(V0, V1, V2) :- nextrow(V68, V67), nextrow(V1, V68), int(V0), row(V1), col(V2), int(V2), row(V67), row(V68).
next_connected(V0, V1, V2) :- true_connected(V0, V1, V2), col(V0), int(V0), row(V1), col(V2), int(V2).
