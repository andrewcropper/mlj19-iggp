
true.

% learning next_plowed/4
% clauses: 1
% clauses: 2
