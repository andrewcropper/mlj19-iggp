
true.

% learning next_has_force_noop/2
% clauses: 1
next_has_force_noop(A,B):-my_true_has_force_noop(A,B),not_does_force_noop(A,B,C).
