
true.

% learning legal_raise/4
% clauses: 1
% clauses: 2
