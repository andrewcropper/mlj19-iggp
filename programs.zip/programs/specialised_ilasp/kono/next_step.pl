
next_step(V0) :- succ(V23, V0), true_step(V23), int(V0), int(V23).
