
next_rounds(V0) :- succ(V92, V0), true_rounds(V92), int(V0), int(V92).
