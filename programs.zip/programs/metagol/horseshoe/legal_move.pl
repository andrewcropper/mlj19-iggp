
true.

% learning legal_move/4
% clauses: 1
% clauses: 2
% clauses: 3
