
true.

% learning legal_pawnmove/6
% clauses: 1
% clauses: 2
% clauses: 3
% clauses: 4
