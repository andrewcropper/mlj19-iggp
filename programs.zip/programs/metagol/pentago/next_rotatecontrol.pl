
true.

% learning next_rotatecontrol/2
% clauses: 1
next_rotatecontrol(A,B):-my_true_placecontrol(A,B).
