
true.

% learning next_dir/3
% clauses: 1
% clauses: 2
