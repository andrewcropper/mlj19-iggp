
next_captures(V0) :- succ(V5, V0), succ(V6, V5), add2row(V8, V6), true_cell(V5, V8, V29), V29 = blank, int(V0), pos(V5), int(V5), pos(V6), int(V6), pos(V8), int(V8), mark(V29).
next_captures(V0) :- does_move(V26, V0, V8, V15, V0), pos(V0), int(V0), pos(V8), int(V8), pos(V15), int(V15), agent(V26).
