
next_cell(V0, V1) :- does_jump(V9, V0, V5), V1 = zerocoins, pos(V0), cell_value(V1), pos(V5), agent(V9).
next_cell(V0, V1) :- does_jump(V9, V2, V0), V1 = twocoins, pos(V0), cell_value(V1), pos(V2), agent(V9).
next_cell(V0, V1) :- true_cell(V0, V1), does_jump(V9, V2, V5), V1 = twocoins, pos(V0), cell_value(V1), pos(V2), pos(V5), agent(V9).
next_cell(V0, V1) :- true_cell(V2, V1), does_jump(V9, V2, V6), V0 = 1, V2 = 7, pos(V0), cell_value(V1), pos(V2), pos(V6), agent(V9).
next_cell(V0, V1) :- succ(V0, V7), true_cell(V0, V1), does_jump(V9, V5, V7), pos(V0), cell_value(V1), pos(V5), pos(V7), agent(V9).
next_cell(V0, V1) :- succ(V6, V5), true_cell(V6, V1), does_jump(V9, V5, V7), not true_step(V0), V0 = 3, pos(V0), cell_value(V1), pos(V5), pos(V6), pos(V7), agent(V9).
next_cell(V0, V1) :- succ(V7, V6), true_cell(V0, V1), does_jump(V9, V4, V7), V0 = 8, pos(V0), cell_value(V1), pos(V4), pos(V6), pos(V7), agent(V9).
next_cell(V0, V1) :- succ(V8, V7), true_cell(V0, V1), does_jump(V9, V5, V8), not true_step(V5), V0 = 6, pos(V0), cell_value(V1), pos(V5), pos(V7), pos(V8), agent(V9).
next_cell(V0, V1) :- succ(V4, V3), succ(V5, V4), true_cell(V0, V1), does_jump(V9, V5, V8), V0 = 7, pos(V0), cell_value(V1), pos(V3), pos(V4), pos(V5), pos(V8), agent(V9).
next_cell(V0, V1) :- true_cell(V0, V1), does_jump(V9, V4, V6), V1 = zerocoins, pos(V0), cell_value(V1), pos(V4), pos(V6), agent(V9).
next_cell(V0, V1) :- true_step(V7), true_cell(V0, V1), V0 = 4, V7 = 2, pos(V0), cell_value(V1), pos(V7).
next_cell(V0, V1) :- succ(V0, V4), true_cell(V0, V1), does_jump(V9, V4, V6), pos(V0), cell_value(V1), pos(V4), pos(V6), agent(V9).
next_cell(V0, V1) :- succ(V0, V8), true_cell(V8, V1), true_cell(V0, V1), does_jump(V9, V4, V7), V4 = 6, pos(V0), cell_value(V1), pos(V4), pos(V7), pos(V8), agent(V9).
next_cell(V0, V1) :- true_step(V0), does_jump(V9, V4, V7), V4 = 6, pos(V0), cell_value(V1), pos(V4), pos(V7), agent(V9).
