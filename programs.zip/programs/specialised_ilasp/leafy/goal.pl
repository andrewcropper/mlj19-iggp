
goal(V0, V1) :- close(V9, V10), true_isplayer(V9, V4, V2), true_isplayer(V10, V9, V0), V1 = 0, agent(V0), int(V1), agent(V2), pos(V4), pos(V9), pos(V10).
goal(V0, V1) :- close(V9, V10), true_isplayer(V9, V4, V0), true_isplayer(V10, V9, V2), V1 = 100, agent(V0), int(V1), agent(V2), pos(V4), pos(V9), pos(V10).
goal(V0, V1) :- close(V5, V6), true_isplayer(V5, V8, V2), true_isplayer(V6, V3, V0), V1 = 0, V3 = 8, agent(V0), int(V1), agent(V2), pos(V3), pos(V5), pos(V6), pos(V8).
goal(V0, V1) :- close(V5, V6), true_isplayer(V5, V8, V0), true_isplayer(V6, V3, V2), V1 = 100, V3 = 8, agent(V0), int(V1), agent(V2), pos(V3), pos(V5), pos(V6), pos(V8).
goal(V0, V1) :- true_leaf(V10, V6), true_isplayer(V6, V7, V2), true_isplayer(V10, V7, V0), V1 = 100, V10 = 1, agent(V0), int(V1), agent(V2), pos(V6), pos(V7), pos(V10).
goal(V0, V1) :- close(V9, V10), true_leaf(V9, V7), true_isplayer(V10, V7, V2), V1 = 50, V2 = red, agent(V0), int(V1), agent(V2), pos(V7), pos(V9), pos(V10).
goal(V0, V1) :- true_leaf(V10, V6), true_isplayer(V6, V7, V0), true_isplayer(V10, V7, V2), V1 = 0, V10 = 1, agent(V0), int(V1), agent(V2), pos(V6), pos(V7), pos(V10).
goal(V0, V1) :- close(V9, V10), true_leaf(V9, V10), true_isplayer(V10, V7, V2), V7 = 4, V10 = 1, agent(V0), int(V1), agent(V2), pos(V7), pos(V9), pos(V10).
goal(V0, V1) :- true_leaf(V6, V3), true_leaf(V6, V6), V1 = 50, V3 = 8, V6 = 5, agent(V0), int(V1), pos(V3), pos(V6).
