
true.

% learning legal_plow_col/3
% clauses: 1
% clauses: 2
