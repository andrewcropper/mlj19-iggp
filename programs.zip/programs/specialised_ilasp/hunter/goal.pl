
goal(V0, V1) :- scoremap(V5, V1), true_captures(V5), agent(V0), int(V1), int(V5).
