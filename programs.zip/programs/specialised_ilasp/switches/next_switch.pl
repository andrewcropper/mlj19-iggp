
next_switch(V0, V1, V2) :- true_switch(V0, V1, V2), pos(V0), pos(V1), obj(V2).
