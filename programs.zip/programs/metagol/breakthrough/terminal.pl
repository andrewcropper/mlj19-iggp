
true.

% learning terminal/1
% clauses: 1
% clauses: 2
% clauses: 3
% clauses: 4
