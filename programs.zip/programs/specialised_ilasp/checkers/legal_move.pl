
legal_move(V0, V1, V2, V3, V4) :- redpawnmove(V2, V23, V23, V1), agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), pos(V4), int(V4), pos(V23), int(V23).
legal_move(V0, V1, V2, V3, V4) :- redpawnmove(V7, V3, V3, V1), agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), pos(V4), int(V4), pos(V7), int(V7).
