
next_step(V0) :- pp(V12, V0), true_step(V12), int(V0), int(V12).
