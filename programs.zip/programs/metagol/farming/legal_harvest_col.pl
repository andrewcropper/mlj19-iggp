
true.

% learning legal_harvest_col/3
% clauses: 1
% clauses: 2
