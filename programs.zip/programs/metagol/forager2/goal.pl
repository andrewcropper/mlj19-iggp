
true.

% learning goal/3
% clauses: 1
goal(A,B,C):-not_bounds(A,B),my_true_score(A,C).
