
true.

% learning next_color/3
% clauses: 1
% clauses: 2
