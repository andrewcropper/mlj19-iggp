
legal_move(V0, V1, V2, V3, V4) :- true_cell(V1, V2, V0), agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), pos(V4), int(V4).
