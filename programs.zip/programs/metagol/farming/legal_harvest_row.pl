
true.

% learning legal_harvest_row/3
% clauses: 1
% clauses: 2
