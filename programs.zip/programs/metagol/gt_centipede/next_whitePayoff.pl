
true.

% learning next_whitePayoff/2
% clauses: 1
% clauses: 2
% clauses: 3
% clauses: 4
