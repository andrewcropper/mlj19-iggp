
true.

% learning next_year_first_player/2
% clauses: 1
% clauses: 2
