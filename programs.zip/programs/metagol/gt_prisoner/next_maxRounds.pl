
true.

% learning next_maxRounds/2
% clauses: 1
next_maxRounds(A,B):-my_true_maxRounds(A,B).
