
true.

% learning next_on/3
% clauses: 1
% clauses: 2
% clauses: 3
