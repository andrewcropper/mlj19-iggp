
next_control(V0) :- not true_control(V0), agent(V0).
