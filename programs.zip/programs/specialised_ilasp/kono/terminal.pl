
terminal :- true_step(V11), V11 = 30, int(V11).
