
true.

% learning next_sheep/4
% clauses: 1
% clauses: 2
