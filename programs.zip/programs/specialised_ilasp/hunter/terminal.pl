
terminal :- true_step(V10), V10 = 16, int(V10).
