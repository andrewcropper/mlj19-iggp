
true.

% learning next_coled/2
% clauses: 1
% clauses: 2
