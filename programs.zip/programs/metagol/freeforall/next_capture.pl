
true.

% learning next_capture/3
% clauses: 1
% clauses: 2
