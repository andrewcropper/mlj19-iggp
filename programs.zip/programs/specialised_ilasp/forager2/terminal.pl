
terminal :- world_min(V4), player_object(V17), true_at(V0, V4, V17), not true_score(V0), not true_time(V0), int(V0), int(V4), obj(V17).
terminal :- world_succ(V2, V0), red_object(V16), player_object(V17), true_at(V2, V3, V16), true_at(V3, V2, V17), int(V0), int(V2), int(V3), obj(V16), obj(V17).
terminal :- world_succ(V2, V0), true_at(V0, V2, V17), true_at(V2, V2, V13), not true_score(V0), not true_time(V2), int(V0), int(V2), obj(V13), obj(V17).
terminal :- world_max(V1), player_object(V17), true_at(V2, V1, V17), true_at(V2, V2, V13), int(V1), int(V2), obj(V13), obj(V17).
