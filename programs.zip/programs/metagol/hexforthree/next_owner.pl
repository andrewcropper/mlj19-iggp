
true.

% learning next_owner/3
% clauses: 1
% clauses: 2
next_owner(A,B,C):-my_true_step(A,B),my_true_control(A,C).
next_owner(A,B,C):-my_true_owner(A,B,C).
