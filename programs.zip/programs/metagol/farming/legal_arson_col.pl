
true.

% learning legal_arson_col/3
% clauses: 1
% clauses: 2
