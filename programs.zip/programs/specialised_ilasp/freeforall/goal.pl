
goal(V0, V1) :- scoremap(V1, V1), agent(V0), int(V1).
