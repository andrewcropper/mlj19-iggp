
true.

% learning legal/3
% clauses: 1
% clauses: 2
legal(A,B,C):-not_my_succ(A,B,C),legal_1(A).
legal_1(A):-my_true_maxRounds(A,B),not_my_true_rounds(A,B).
