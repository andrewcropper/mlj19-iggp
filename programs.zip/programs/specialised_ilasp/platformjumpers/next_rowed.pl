
next_rowed(V0) :- true_cell(V11, V0, V0), pos(V0), agent(V11).
