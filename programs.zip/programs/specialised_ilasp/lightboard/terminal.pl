
terminal :- true_step(V1), V1 = 9, int(V1).
