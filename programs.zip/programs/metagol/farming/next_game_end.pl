
true.

next_game_end(A,B):-false.
