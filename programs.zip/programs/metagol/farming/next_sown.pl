
true.

% learning next_sown/4
% clauses: 1
% clauses: 2
