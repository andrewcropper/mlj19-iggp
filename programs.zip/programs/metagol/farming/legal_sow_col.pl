
true.

% learning legal_sow_col/3
% clauses: 1
% clauses: 2
