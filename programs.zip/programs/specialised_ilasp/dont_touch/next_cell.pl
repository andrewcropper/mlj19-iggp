
next_cell(V0, V1, V2) :- succ(V8, V1), true_cell(V0, V1, V2), does(V10, V11), pos(V0), pos(V1), cell_type(V2), pos(V8), agent(V10), action(V11).
next_cell(V0, V1, V2) :- true_cell(V0, V1, V2), V2 = o, pos(V0), pos(V1), cell_type(V2).
next_cell(V0, V1, V2) :- succ(V8, V0), true_cell(V0, V8, V2), does_mark(V9, V8, V1), pos(V0), pos(V1), cell_type(V2), pos(V8), agent(V9).
next_cell(V0, V1, V2) :- does_mark(V9, V0, V1), V2 = x, pos(V0), pos(V1), cell_type(V2), agent(V9).
next_cell(V0, V1, V2) :- true_cell(V0, V1, V2), does_mark(V9, V7, V0), pos(V0), pos(V1), cell_type(V2), pos(V7), agent(V9).
next_cell(V0, V1, V2) :- true_cell(V0, V1, V2), V2 = x, pos(V0), pos(V1), cell_type(V2).
next_cell(V0, V1, V2) :- true_cell(V7, V7, V12), true_cell(V7, V0, V2), V0 = 2, V12 = o, pos(V0), pos(V1), cell_type(V2), pos(V7), cell_type(V12).
