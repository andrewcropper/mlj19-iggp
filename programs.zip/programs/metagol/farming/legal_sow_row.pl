
true.

% learning legal_sow_row/3
% clauses: 1
% clauses: 2
