
true.

% learning next_target/3
% clauses: 1
next_target(A,B,C):-my_true_target(A,B,C).
