
true.

% learning next_rowed/2
% clauses: 1
% clauses: 2
