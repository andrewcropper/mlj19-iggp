
true.

legal_horizontal(A,B,C,D,E,F):-false.
