
true.

% learning goal/3
% clauses: 1
% clauses: 2
goal(A,B,C):-not_add1col(A,B,D),goal_1(A,D,C).
goal_1(A,B,C):-my_true_captures(A,B),scoremap(A,B,C).
