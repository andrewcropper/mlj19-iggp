
next_claim_made_by(V0) :- does(V0, V23), V23 = lay_claim, agent(V0), action(V23).
