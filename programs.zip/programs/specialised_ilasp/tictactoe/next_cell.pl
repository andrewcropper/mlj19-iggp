
next_cell(V0, V1, V2) :- true_cell(V0, V1, V2), V2 = o, pos(V0), pos(V1), mark(V2).
next_cell(V0, V1, V2) :- does_mark(V3, V0, V1), V2 = x, V3 = white, pos(V0), pos(V1), mark(V2), agent(V3).
next_cell(V0, V1, V2) :- true_cell(V0, V5, V7), true_cell(V0, V1, V2), true_cell(V5, V1, V2), V7 = x, pos(V0), pos(V1), mark(V2), pos(V5), mark(V7).
next_cell(V0, V1, V2) :- true_cell(V0, V0, V7), true_cell(V0, V1, V2), true_cell(V1, V5, V7), V1 = 2, pos(V0), pos(V1), mark(V2), pos(V5), mark(V7).
next_cell(V0, V0, V1) :- true_control(V2), true_cell(V0, V0, V1), V2 = white, pos(V0), mark(V1), agent(V2).
next_cell(V0, V1, V2) :- true_cell(V5, V1, V8), true_cell(V5, V0, V2), true_cell(V0, V1, V2), V8 = x, pos(V0), pos(V1), mark(V2), pos(V5), mark(V8).
next_cell(V0, V1, V2) :- true_cell(V0, V1, V2), does_mark(V3, V0, V5), V1 = 1, V5 = 2, pos(V0), pos(V1), mark(V2), agent(V3), pos(V5).
next_cell(V0, V1, V2) :- true_cell(V5, V0, V7), true_cell(V0, V1, V2), true_cell(V1, V0, V7), V0 = 2, V5 = 3, pos(V0), pos(V1), mark(V2), pos(V5), mark(V7).
next_cell(V0, V1, V2) :- true_cell(V0, V0, V2), does(V3, V6), V1 = 1, V3 = white, pos(V0), pos(V1), mark(V2), agent(V3), action(V6).
next_cell(V0, V1, V2) :- true_cell(V0, V5, V2), does_mark(V3, V1, V0), V5 = 1, pos(V0), pos(V1), mark(V2), agent(V3), pos(V5).
