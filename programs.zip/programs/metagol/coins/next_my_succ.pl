
true.

next_my_succ(A,B,C):-false.
