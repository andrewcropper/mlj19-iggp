
next_step(V0) :- succ(V18, V0), true_step(V18), int(V0), int(V18).
