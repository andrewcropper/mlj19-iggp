
true.

% learning goal/3
% clauses: 1
% clauses: 2
goal(A,B,C):-not_scoreMap(A,B,D),goal_1(A,D,C).
goal_1(A,B,C):-my_true_moveCount(A,B),scoreMap(A,B,C).
