
true.

next_r(A,B):-false.
