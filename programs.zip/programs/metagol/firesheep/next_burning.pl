
true.

% learning next_burning/4
% clauses: 1
% clauses: 2
