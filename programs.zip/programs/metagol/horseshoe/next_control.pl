
true.

% learning next_control/2
% clauses: 1
next_control(A,B):-not_my_true_control(A,B).
