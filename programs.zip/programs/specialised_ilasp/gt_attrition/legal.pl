
legal(V0, V1) :- true_control(V0), V1 = lay_claim, agent(V0), action(V1).
legal(V0, V1) :- true_control(V0), V1 = end_game, agent(V0), action(V1).
legal(V0, V1) :- not true_control(V0), V1 = noop, agent(V0), action(V1).
