
legal_jump(V0, V1, V2, V1, V3) :- true_cell(V2, V2, V119), true_cell(V1, V3, V120), V120 = floor, agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), object(V119), object(V120).
legal_jump(V0, V1, V2, V3, V2) :- true_correctToads(V1), true_cell(V3, V2, V120), V2 = 6, V120 = floor, agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), object(V120).
legal_jump(V0, V1, V2, V3, V2) :- true_cell(V1, V2, V118), true_cell(V3, V2, V120), V1 = 6, V120 = floor, agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), object(V118), object(V120).
