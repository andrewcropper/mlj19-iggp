
legal_place(V0, V1, V2) :- adjacent(V67, V5, V1, V2), true_connected(V38, V67, V5), agent(V0), row(V1), col(V2), int(V2), col(V5), int(V5), int(V38), row(V67).
