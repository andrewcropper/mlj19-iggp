
true.

% learning terminal/1
% clauses: 1
terminal(A):-my_true(A,7).
