
true.

% learning next_isplayer/4
% clauses: 1
% clauses: 2
next_isplayer(A,B,C,D):-next_isplayer_1(A,B,D,C).
next_isplayer_1(A,B,C,D):-does_move(A,C,B,D).
