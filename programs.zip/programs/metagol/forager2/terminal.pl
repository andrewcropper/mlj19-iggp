
true.

% learning terminal/1
% clauses: 1
terminal(A):-not_my_true_time(A,B).
