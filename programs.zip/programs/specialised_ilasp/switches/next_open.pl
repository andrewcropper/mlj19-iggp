
next_open(V0, V1) :- succ(V1, V5), true_open(V0, V5), obj(V0), pos(V1), pos(V5).
next_open(V0, V1) :- true_target(V1, V5), true_switch(V3, V4, V0), true_at(V3, V4, V7), obj(V0), pos(V1), pos(V3), pos(V4), pos(V5), obj(V7).
