
true.

% learning legal_water_col/3
% clauses: 1
% clauses: 2
