
true.

% learning goal/3
% clauses: 1
% clauses: 2
% clauses: 3
goal(A,B,C):-my_true_score(A,B,C),my_true_gameOver(A).
goal(A,B,C):-goal_1(A,B,C),not_my_true_gameOver(A).
goal_1(A,B,C):-not_my_succ(A,B,D),not_my_succ(A,D,C).
