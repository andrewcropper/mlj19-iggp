
true.

% learning terminal/1
% clauses: 1
terminal(A):-my_true_count(A,31).
