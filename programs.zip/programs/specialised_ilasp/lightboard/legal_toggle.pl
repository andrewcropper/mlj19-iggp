
legal_toggle(V0, V1, V2) :- agent(V0), pos(V1), int(V1), pos(V2), int(V2).
