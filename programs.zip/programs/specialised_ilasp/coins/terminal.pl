
terminal :- succ(V6, V5), true_cell(V5, V11), true_cell(V6, V11), V5 = 3, V11 = twocoins, pos(V5), pos(V6), cell_value(V11).
terminal :- true_step(V5), true_cell(V4, V11), true_cell(V5, V11), V4 = 4, V11 = twocoins, pos(V4), pos(V5), cell_value(V11).
terminal :- succ(V2, V0), true_cell(V0, V10), true_cell(V2, V10), V0 = 7, V10 = twocoins, pos(V0), pos(V2), cell_value(V10).
terminal :- true_step(V4), true_cell(V0, V10), V0 = 7, V4 = 4, V10 = onecoin, pos(V0), pos(V4), cell_value(V10).
terminal :- succ(V4, V3), true_cell(V3, V11), true_cell(V4, V11), V3 = 5, V11 = twocoins, pos(V3), pos(V4), cell_value(V11).
terminal :- true_step(V4), true_cell(V6, V11), V4 = 4, V6 = 2, V11 = onecoin, pos(V4), pos(V6), cell_value(V11).
terminal :- succ(V3, V2), true_cell(V2, V11), true_cell(V3, V11), V2 = 6, V11 = twocoins, pos(V2), pos(V3), cell_value(V11).
