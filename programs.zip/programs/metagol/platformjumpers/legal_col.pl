
true.

% learning legal_col/3
% clauses: 1
legal_col(A,B,C):-my_true_control(A,B),not_my_true_coled(A,C).
