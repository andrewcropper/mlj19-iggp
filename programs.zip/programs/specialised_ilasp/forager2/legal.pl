
legal(V0, V1) :- agent(V0), action(V1).
