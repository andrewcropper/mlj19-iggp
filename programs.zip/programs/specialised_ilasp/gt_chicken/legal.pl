
legal(V0, V1) :- true_rounds(V93), not maxRounds(V93), agent(V0), action(V1), int(V93).
