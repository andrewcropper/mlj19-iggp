
next_cell(V0, V1, V2) :- true_connected(V61, V0, V1), row(V0), col(V1), int(V1), agent(V2), int(V61).
