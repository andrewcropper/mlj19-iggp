
next_score(V0, V1) :- succ(V1, V8), true_score(V0, V8), does(V0, V23), V23 = lay_claim, agent(V0), int(V1), int(V8), action(V23).
next_score(V0, V1) :- true_score(V0, V10), V1 = 80, V10 = 55, agent(V0), int(V1), int(V10).
next_score(V0, V1) :- opponent(V0, V22), true_score(V0, V1), does(V22, V24), V24 = lay_claim, agent(V0), int(V1), agent(V22), action(V24).
next_score(V0, V1) :- true_claim_made_by(V0), does(V22, V23), V0 = black, V1 = 90, V23 = end_game, agent(V0), int(V1), agent(V22), action(V23).
next_score(V0, V1) :- true_score(V22, V1), does(V22, V23), not true_claim_made_by(V0), V23 = end_game, agent(V0), int(V1), agent(V22), action(V23).
next_score(V0, V1) :- true_score(V22, V7), does(V22, V23), V7 = 70, V23 = end_game, agent(V0), int(V1), int(V7), agent(V22), action(V23).
