
next_cell(V0, V1, V2) :- stepcount(V1, V8), true_cell(V1, V8, V32), pos(V0), int(V0), pos(V1), int(V1), agent(V2), pos(V8), int(V8), agent(V32).
