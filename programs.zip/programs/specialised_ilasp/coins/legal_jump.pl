
legal_jump(V0, V1, V2) :- true_cell(V2, V10), V1 = 7, V2 = 4, V10 = onecoin, agent(V0), pos(V1), pos(V2), cell_value(V10).
legal_jump(V0, V1, V2) :- true_cell(V1, V10), V1 = 4, V2 = 7, V10 = onecoin, agent(V0), pos(V1), pos(V2), cell_value(V10).
legal_jump(V0, V1, V2) :- true_step(V7), V1 = 8, V2 = 5, V7 = 2, agent(V0), pos(V1), pos(V2), pos(V7).
legal_jump(V0, V1, V2) :- true_step(V7), V1 = 5, V2 = 8, V7 = 2, agent(V0), pos(V1), pos(V2), pos(V7).
legal_jump(V0, V1, V2) :- succ(V7, V1), true_step(V7), V1 = 3, V2 = 5, agent(V0), pos(V1), pos(V2), pos(V7).
legal_jump(V0, V1, V2) :- succ(V7, V2), true_step(V7), V1 = 5, V2 = 3, agent(V0), pos(V1), pos(V2), pos(V7).
legal_jump(V0, V1, V2) :- true_cell(V5, V10), not true_step(V1), V1 = 3, V5 = 6, V10 = zerocoins, agent(V0), pos(V1), pos(V2), pos(V5), cell_value(V10).
legal_jump(V0, V1, V2) :- true_cell(V5, V10), V1 = 1, V2 = 3, V5 = 6, V10 = zerocoins, agent(V0), pos(V1), pos(V2), pos(V5), cell_value(V10).
