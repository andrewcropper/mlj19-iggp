
true.

% learning goal/3
% clauses: 1
% clauses: 2
% clauses: 3
goal(A,you,100):-my_true_step(A,5).
goal(A,you,0):-goal_1(A,4).
goal_1(A,B):-my_succ(A,B,C),not_my_true_step(A,C).
