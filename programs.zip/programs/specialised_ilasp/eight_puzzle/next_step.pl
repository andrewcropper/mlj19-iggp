
next_step(V0) :- successor(V20, V0), true_step(V20), time_step(V0), score_int(V0), time_step(V20), score_int(V20).
