
next_cell(V0, V0, V1) :- scoremap(V0, V9), pos(V0), int(V0), mark(V1), pos(V9), int(V9).
next_cell(V0, V1, V2) :- knightmove(V0, V9, V8, V1), true_cell(V0, V10, V2), pos(V0), int(V0), pos(V1), int(V1), mark(V2), pos(V8), int(V8), pos(V9), int(V9), pos(V10), int(V10).
