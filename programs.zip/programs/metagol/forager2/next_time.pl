
true.

% learning next_time/2
% clauses: 1
next_time(A,B):-my_succ(A,B,C),my_true_time(A,C).
