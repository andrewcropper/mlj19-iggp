
true.

% learning legal/3
% clauses: 1
legal(A,B,C):-not_my_succ(A,B,C).
