
legal_move(V0, V1, V2, V3, V2) :- triplet(V1, V1, V1, V3, V1, V2), agent(V0), mark(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3).
legal_move(V0, V1, V2, V3, V2) :- vertical(V3, V1, V3, V3), agent(V0), mark(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3).
legal_move(V0, V1, V2, V1, V3) :- vertical(V4, V1, V4, V4), agent(V0), mark(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), pos(V4), int(V4).
legal_move(V0, V1, V2, V1, V3) :- vertical(V4, V3, V4, V4), V2 = 2, agent(V0), mark(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), pos(V4), int(V4).
