
legal_jump(V0, V1, V2, V3, V4) :- valid_move(V5, V3, V6, V1, V1), agent(V0), pos(V1), pos(V2), pos(V3), pos(V4), agent(V5), pos(V6).
