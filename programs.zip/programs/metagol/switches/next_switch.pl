
true.

% learning next_switch/4
% clauses: 1
next_switch(A,B,C,D):-my_true_switch(A,B,C,D).
