
next_blackScore(V0) :- true_blackScore(V51), V0 = 57, V51 = 54, int(V0), int(V51).
next_blackScore(V0) :- true_blackScore(V60), V0 = 51, V60 = 46, int(V0), int(V60).
next_blackScore(V0) :- true_whiteScore(V100), true_rounds(V100), V0 = 4, int(V0), int(V100).
next_blackScore(V0) :- true_blackScore(V0), V0 = 33, int(V0).
next_blackScore(V0) :- succ(V88, V0), succ(V90, V88), succ(V91, V90), true_blackScore(V91), V0 = 21, int(V0), int(V88), int(V90), int(V91).
next_blackScore(V0) :- true_whiteScore(V47), V0 = 50, V47 = 59, int(V0), int(V47).
next_blackScore(V0) :- succ(V63, V0), succ(V64, V63), succ(V65, V64), true_blackScore(V65), V0 = 44, int(V0), int(V63), int(V64), int(V65).
next_blackScore(V0) :- succ(V68, V0), succ(V69, V68), succ(V70, V69), true_blackScore(V70), V0 = 40, int(V0), int(V68), int(V69), int(V70).
next_blackScore(V0) :- true_whiteScore(V68), V0 = 54, V68 = 39, int(V0), int(V68).
next_blackScore(V0) :- true_blackScore(V0), V0 = 34, int(V0).
next_blackScore(V0) :- true_whiteScore(V49), V0 = 52, V49 = 57, int(V0), int(V49).
next_blackScore(V0) :- true_blackScore(V0), V0 = 56, int(V0).
next_blackScore(V0) :- succ(V75, V74), succ(V0, V75), true_whiteScore(V81), V81 = 27, int(V0), int(V74), int(V75), int(V81).
