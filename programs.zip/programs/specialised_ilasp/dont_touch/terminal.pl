
terminal :- succ(V7, V6), true_cell(V4, V6, V12), true_cell(V4, V7, V12), V12 = x, pos(V4), pos(V6), pos(V7), cell_type(V12).
terminal :- succ(V5, V4), true_cell(V4, V7, V12), true_cell(V5, V7, V12), V12 = x, pos(V4), pos(V5), pos(V7), cell_type(V12).
terminal :- succ(V7, V6), true_cell(V6, V5, V13), true_cell(V7, V5, V13), V13 = o, pos(V5), pos(V6), pos(V7), cell_type(V13).
terminal :- succ(V6, V5), true_cell(V7, V5, V13), true_cell(V7, V6, V13), V13 = o, pos(V5), pos(V6), pos(V7), cell_type(V13).
