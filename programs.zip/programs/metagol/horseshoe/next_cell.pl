
true.

% learning next_cell/3
% clauses: 1
% clauses: 2
% clauses: 3
