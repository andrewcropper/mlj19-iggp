
true.

% learning legal_burn/3
% clauses: 1
% clauses: 2
