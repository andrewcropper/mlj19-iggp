
next_moveCount(V0) :- add(V49, V56, V1, V0), add(V49, V56, V50, V49), true_moveCount(V1), int(V0), int(V1), pos(V49), int(V49), int(V50), add_arg(V56).
