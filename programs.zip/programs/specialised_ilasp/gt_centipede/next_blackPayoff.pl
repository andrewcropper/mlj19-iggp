
next_blackPayoff(V0) :- succ(V14, V0), succ(V15, V14), true_whitePayoff(V15), does(V21, V23), V23 = continue, int(V0), int(V14), int(V15), agent(V21), action(V23).
next_blackPayoff(V0) :- true_blackPayoff(V0), does(V21, V23), V23 = finish, int(V0), agent(V21), action(V23).
