
true.

% learning next_moveCount/2
% clauses: 1
% clauses: 2
% clauses: 3
