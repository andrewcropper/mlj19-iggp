
true.

% learning next_has_arson/2
% clauses: 1
% clauses: 2
