
next_on(V0, V1) :- successor(V1, V5), does_toggle(V9, V0, V1), not true_step(V5), pos(V0), int(V0), pos(V1), int(V1), pos(V5), int(V5), agent(V9).
next_on(V0, V1) :- successor(V1, V0), true_step(V5), true_on(V0, V1), pos(V0), int(V0), pos(V1), int(V1), pos(V5), int(V5).
next_on(V0, V1) :- successor(V8, V7), true_on(V0, V1), does_toggle(V9, V6, V8), not true_step(V7), pos(V0), int(V0), pos(V1), int(V1), pos(V6), int(V6), pos(V7), int(V7), pos(V8), int(V8), agent(V9).
next_on(V0, V1) :- does_toggle(V9, V0, V1), not true_step(V6), V6 = 4, pos(V0), int(V0), pos(V1), int(V1), pos(V6), int(V6), agent(V9).
next_on(V0, V1) :- true_step(V3), true_on(V0, V1), not true_step(V5), V5 = 4, pos(V0), int(V0), pos(V1), int(V1), pos(V3), int(V3), pos(V5), int(V5).
