
next_leaf(V0, V1) :- true_leaf(V0, V1), V1 = 1, pos(V0), pos(V1).
next_leaf(V0, V1) :- true_leaf(V0, V0), pos(V0), pos(V1).
next_leaf(V0, V1) :- true_leaf(V8, V1), true_leaf(V0, V1), true_leaf(V9, V1), V8 = 3, V9 = 1, pos(V0), pos(V1), pos(V8), pos(V9).
