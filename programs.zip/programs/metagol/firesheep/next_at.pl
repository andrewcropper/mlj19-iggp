
true.

% learning next_at/4
% clauses: 1
% clauses: 2
