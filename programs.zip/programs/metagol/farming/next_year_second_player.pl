
true.

% learning next_year_second_player/2
% clauses: 1
% clauses: 2
