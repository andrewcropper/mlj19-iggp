
true.

% learning next_control/2
% clauses: 1
% clauses: 2
% clauses: 3
