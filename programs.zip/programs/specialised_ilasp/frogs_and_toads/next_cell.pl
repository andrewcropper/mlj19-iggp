
next_cell(V0, V1, V2) :- V0 = 4, pos(V0), int(V0), pos(V1), int(V1), object(V2).
next_cell(V0, V1, V2) :- V0 = 5, pos(V0), int(V0), pos(V1), int(V1), object(V2).
next_cell(V0, V1, V2) :- V0 = 2, pos(V0), int(V0), pos(V1), int(V1), object(V2).
next_cell(V0, V1, V2) :- succ(V90, V0), succ(V116, V90), true_cell(V1, V0, V119), true_cell(V116, V1, V2), pos(V0), int(V0), pos(V1), int(V1), object(V2), pos(V90), int(V90), pos(V116), int(V116), object(V119).
