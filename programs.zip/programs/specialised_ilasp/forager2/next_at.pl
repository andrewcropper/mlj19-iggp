
next_at(V0, V1, V2) :- true_at(V0, V1, V2), not player_object(V2), int(V0), int(V1), obj(V2).
next_at(V0, V1, V2) :- world_succ(V5, V1), player_object(V2), true_time(V3), true_at(V0, V5, V2), not true_score(V1), int(V0), int(V1), obj(V2), int(V3), int(V5).
next_at(V0, V1, V2) :- world_succ(V0, V5), is_left(V25), true_at(V5, V1, V2), does(V12, V25), int(V0), int(V1), obj(V2), int(V5), agent(V12), action(V25).
