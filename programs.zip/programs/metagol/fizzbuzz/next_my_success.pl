
true.

% learning next_my_success/2
% clauses: 1
% clauses: 2
