
true.

legal_vertical(A,B,C,D,E,F):-false.
