
true.

% learning legal/3
% clauses: 1
legal(A,B,C):-my_input(A,B,C).
