
next_cell(V0, V1, V2) :- true_cell(V0, V1, V2), int(V0), int(V1), agent(V2).
next_cell(V0, V0, V1) :- does_move(V1, V7, V7, V0, V0), int(V0), agent(V1), int(V7).
