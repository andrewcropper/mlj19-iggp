
true.

% learning goal/3
% clauses: 1
% clauses: 2
goal(A,player,10):-goal_1(A).
goal_1(A):-even(A,B),my_true_chosen(A,B).
