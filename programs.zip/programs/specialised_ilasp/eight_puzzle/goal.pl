
goal(V0, V1) :- true_cell(V9, V8, V10), V1 = 0, V9 = 2, agent(V0), time_step(V1), score_int(V1), pos(V8), cell_type(V8), time_step(V8), score_int(V8), pos(V9), cell_type(V9), time_step(V9), score_int(V9), pos(V10), cell_type(V10), time_step(V10), score_int(V10).
goal(V0, V1) :- true_cell(V8, V10, V4), true_cell(V10, V8, V8), V1 = 100, V4 = 7, V8 = 3, agent(V0), score_int(V1), cell_type(V4), time_step(V4), score_int(V4), pos(V8), cell_type(V8), time_step(V8), score_int(V8), pos(V10), cell_type(V10), time_step(V10), score_int(V10).
goal(V0, V1) :- true_cell(V8, V9, V10), V1 = 0, V8 = 3, agent(V0), time_step(V1), score_int(V1), pos(V8), cell_type(V8), time_step(V8), score_int(V8), pos(V9), cell_type(V9), time_step(V9), score_int(V9), pos(V10), cell_type(V10), time_step(V10), score_int(V10).
