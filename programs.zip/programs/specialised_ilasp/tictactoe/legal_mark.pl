
legal_mark(V0, V1, V2) :- true_control(V0), true_cell(V1, V2, V6), V6 = b, agent(V0), pos(V1), pos(V2), mark(V6).
