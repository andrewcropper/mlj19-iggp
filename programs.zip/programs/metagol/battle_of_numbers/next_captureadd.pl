
true.

next_captureadd(A,B,C):-false.
