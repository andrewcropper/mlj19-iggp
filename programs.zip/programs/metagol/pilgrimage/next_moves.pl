
true.

% learning next_moves/3
% clauses: 1
% clauses: 2
% clauses: 3
