
true.

% learning terminal/1
% clauses: 1
terminal(A):-even(A,B),my_true_chosen(A,B).
