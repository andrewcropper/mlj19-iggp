
true.

% learning next_count/2
% clauses: 1
% clauses: 2
