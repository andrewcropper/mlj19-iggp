
next_isplayer(V0, V1, V2) :- does_move(V2, V0, V1), pos(V0), pos(V1), agent(V2).
