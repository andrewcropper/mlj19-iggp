
true.

% learning legal_rotate/4
% clauses: 1
% clauses: 2
legal_rotate(A,B,C,D):-my_input_rotate(A,B,C,D),legal_rotate_1(A,B,C,D).
legal_rotate_1(A,B,C,D):-my_true_rotatecontrol(A,B),not_my_input(A,C,D).
