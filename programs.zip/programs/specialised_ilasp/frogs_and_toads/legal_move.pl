
legal_move(V0, V1, V2, V1, V3) :- succ(V69, V2), true_cell(V1, V3, V120), true_cell(V1, V2, V119), true_cell(V90, V69, V119), V120 = floor, agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), pos(V69), int(V69), pos(V90), int(V90), object(V119), object(V120).
legal_move(V0, V1, V2, V3, V2) :- succ(V3, V70), succ(V116, V1), true_cell(V70, V70, V119), true_cell(V1, V2, V119), V2 = 6, agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), pos(V70), int(V70), pos(V116), int(V116), object(V119).
legal_move(V0, V1, V2, V3, V2) :- succ(V3, V1), true_cell(V3, V2, V120), V120 = floor, agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), object(V120).
legal_move(V0, V1, V2, V1, V3) :- succ(V3, V2), true_cell(V1, V3, V120), V120 = floor, agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), object(V120).
