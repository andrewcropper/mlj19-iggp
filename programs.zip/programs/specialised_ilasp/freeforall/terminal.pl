
terminal :- true_step(V8), V8 = 31, int(V8).
