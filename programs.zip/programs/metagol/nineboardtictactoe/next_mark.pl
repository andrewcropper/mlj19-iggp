
true.

% learning next_mark/6
% clauses: 1
% clauses: 2
% clauses: 3
next_mark(A,B,C,D,E,F):-does_play(A,oplayer,B,C,D,E,F).
next_mark(A,B,C,D,E,F):-my_true_mark(A,B,C,D,E,F).
next_mark(A,B,C,D,E,F):-does_play(A,xplayer,B,C,D,E,F).
