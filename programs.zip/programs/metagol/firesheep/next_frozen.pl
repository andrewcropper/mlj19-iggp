
true.

% learning next_frozen/4
% clauses: 1
% clauses: 2
