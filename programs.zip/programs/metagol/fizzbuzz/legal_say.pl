
true.

% learning legal_say/3
% clauses: 1
% clauses: 2
legal_say(A,B,C):-my_input_say(A,B,C),not_int(A,C).
legal_say(A,B,C):-not_int(A,B),my_true_count(A,C).
