
true.

next_twomy_between(A,B,C):-false.
