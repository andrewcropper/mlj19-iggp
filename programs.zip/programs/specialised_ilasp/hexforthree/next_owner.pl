
next_owner(V0, V1) :- true_control(V1), int(V0), agent(V1).
next_owner(V0, V1) :- true_owner(V0, V1), int(V0), agent(V1).
