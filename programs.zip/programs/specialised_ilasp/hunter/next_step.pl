
next_step(V0) :- succ(V4, V0), true_step(V4), int(V0), int(V4).
