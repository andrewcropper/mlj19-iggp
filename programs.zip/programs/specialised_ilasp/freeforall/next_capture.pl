
next_capture(V0, V1) :- scoremap(V1, V1), true_step(V7), agent(V0), int(V1), pos(V7), int(V7).
next_capture(V0, V1) :- stepcount(V1, V22), does_move(V0, V22, V22, V11, V11), agent(V0), pos(V1), int(V1), pos(V11), int(V11), pos(V22), int(V22).
