
next_score(V0) :- true_time(V9), V0 = 4, V9 = 6, int(V0), int(V9).
next_score(V0) :- is_right(V24), true_at(V2, V0, V15), does(V11, V24), V15 = red2, int(V0), int(V2), agent(V11), obj(V15), action(V24).
next_score(V0) :- world_min(V4), player_object(V17), true_score(V0), true_at(V2, V1, V17), true_at(V4, V1, V14), int(V0), int(V1), int(V2), int(V4), obj(V14), obj(V17).
next_score(V0) :- bounds(V1), true_time(V1), true_score(V0), int(V0), int(V1).
next_score(V0) :- true_at(V1, V0, V21), does(V11, V26), not true_score(V1), V21 = green2, V26 = down, int(V0), int(V1), agent(V11), obj(V21), action(V26).
next_score(V0) :- world_succ(V1, V0), true_score(V0), true_at(V1, V1, V18), int(V0), int(V1), obj(V18).
