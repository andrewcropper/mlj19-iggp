
true.

% learning legal_arson_row/3
% clauses: 1
% clauses: 2
