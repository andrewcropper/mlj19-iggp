
terminal :- true_connected(V3, V64, V40), V64 = g, col(V3), int(V3), col(V40), int(V40), row(V64).
