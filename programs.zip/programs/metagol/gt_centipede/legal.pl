
true.

% learning legal/3
% clauses: 1
% clauses: 2
% clauses: 3
legal(A,B,finish):-my_true_control(A,B).
legal(A,B,continue):-my_true_control(A,B).
legal(A,B,noop):-not_my_true_control(A,B).
