
true.

% learning next_cellholds/5
% clauses: 1
% clauses: 2
