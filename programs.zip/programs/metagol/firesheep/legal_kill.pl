
true.

% learning legal_kill/3
% clauses: 1
% clauses: 2
