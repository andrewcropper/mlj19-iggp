
true.

% learning next_score/2
% clauses: 1
% clauses: 2
