
legal_jump(V0, V1, V2, V3, V3) :- true_control(V0), agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3).
