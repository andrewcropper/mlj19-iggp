
true.

% learning legal_offer/3
% clauses: 1
% clauses: 2
legal_offer(A,B,C):-legal_offer_1(A,B),my_index(A,C).
legal_offer_1(A,white):-my_true_control(A,white).
