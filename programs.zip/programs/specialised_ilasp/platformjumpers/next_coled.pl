
next_coled(V0) :- true_coled(V0), pos(V0).
