
true.

% learning next_step/2
% clauses: 1
% clauses: 2
