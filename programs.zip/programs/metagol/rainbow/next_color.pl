
true.

% learning next_color/3
% clauses: 1
% clauses: 2
next_color(A,B,C):-my_true_color(A,B,C).
next_color(A,B,C):-does_mark(A,robot,B,C).
