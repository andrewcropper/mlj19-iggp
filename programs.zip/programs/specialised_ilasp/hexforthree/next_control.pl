
next_control(V0) :- redend(V67, V1), true_connected(V4, V71, V1), true_cell(V67, V4, V0), agent(V0), col(V1), int(V1), col(V4), int(V4), row(V67), row(V71).
