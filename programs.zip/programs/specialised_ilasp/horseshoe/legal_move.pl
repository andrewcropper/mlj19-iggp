
legal_move(V0, V1, V2) :- input_move(V23, V2, V1), true_control(V0), true_cell(V2, V27), true_cell(V1, V0), V27 = blank, agent(V0), mark(V0), pos(V1), pos(V2), agent(V23), mark(V23), mark(V27).
