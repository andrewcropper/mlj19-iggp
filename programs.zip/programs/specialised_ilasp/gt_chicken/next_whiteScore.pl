
next_whiteScore(V0) :- succ(V51, V0), true_blackScore(V51), V0 = 55, int(V0), int(V51).
next_whiteScore(V0) :- true_blackScore(V60), V0 = 53, V60 = 46, int(V0), int(V60).
next_whiteScore(V0) :- true_whiteScore(V100), true_rounds(V100), V0 = 4, int(V0), int(V100).
next_whiteScore(V0) :- true_whiteScore(V0), true_rounds(V97), V97 = 12, int(V0), int(V97).
next_whiteScore(V0) :- true_whiteScore(V86), V0 = 27, V86 = 22, int(V0), int(V86).
next_whiteScore(V0) :- succ(V43, V0), succ(V44, V43), succ(V46, V44), true_whiteScore(V46), V0 = 62, int(V0), int(V43), int(V44), int(V46).
next_whiteScore(V0) :- true_blackScore(V66), V0 = 36, V66 = 41, int(V0), int(V66).
next_whiteScore(V0) :- true_whiteScore(V63), V0 = 48, V63 = 43, int(V0), int(V63).
next_whiteScore(V0) :- succ(V65, V0), succ(V66, V65), succ(V68, V66), true_whiteScore(V68), V0 = 42, int(V0), int(V65), int(V66), int(V68).
next_whiteScore(V0) :- true_whiteScore(V0), V0 = 30, int(V0).
next_whiteScore(V0) :- succ(V46, V0), succ(V47, V46), succ(V48, V47), true_whiteScore(V48), V0 = 60, int(V0), int(V46), int(V47), int(V48).
next_whiteScore(V0) :- true_whiteScore(V0), V0 = 64, int(V0).
