
true.

% learning legal_place/5
% clauses: 1
% clauses: 2
