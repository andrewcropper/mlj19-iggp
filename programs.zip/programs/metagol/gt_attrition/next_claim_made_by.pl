
true.

% learning next_claim_made_by/2
% clauses: 1
next_claim_made_by(A,B):-does(A,B,lay_claim).
