
legal_move(V0, V1, V2, V3, V4) :- knightMove(V2, V2, V34, V4), add(V34, V55, V1, V11), agent(V0), pos(V1), int(V1), pos(V2), int(V2), pos(V3), int(V3), pos(V4), int(V4), pos(V11), int(V11), pos(V34), int(V34), add_arg(V55).
