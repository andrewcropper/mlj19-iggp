
goal(V0, V1) :- true_cell(V7, V7, V14), not true_control(V0), V0 = white, V1 = 0, V14 = o, agent(V0), score(V1), pos(V7), cell_type(V14).
goal(V0, V1) :- true_cell(V7, V7, V12), V1 = 50, V7 = 3, V12 = b, agent(V0), score(V1), pos(V7), cell_type(V12).
goal(V0, V1) :- true_control(V0), true_cell(V6, V6, V12), V0 = black, V1 = 100, V12 = o, agent(V0), score(V1), pos(V6), cell_type(V12).
goal(V0, V1) :- true_cell(V6, V6, V12), V1 = 50, V6 = 4, V12 = b, agent(V0), score(V1), pos(V6), cell_type(V12).
