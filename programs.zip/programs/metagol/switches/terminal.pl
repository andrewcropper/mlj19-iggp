
true.

terminal(A):-false.
