
true.

% learning legal_row/3
% clauses: 1
legal_row(A,B,C):-my_true_control(A,B),not_my_true_rowed(A,C).
