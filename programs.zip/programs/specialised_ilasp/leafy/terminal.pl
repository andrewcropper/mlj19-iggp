
terminal :- close(V3, V4), true_leaf(V3, V4), true_isplayer(V3, V3, V0), true_isplayer(V4, V6, V1), agent(V0), agent(V1), pos(V3), pos(V4), pos(V6).
terminal :- true_leaf(V4, V4), true_isplayer(V9, V2, V0), V0 = red, V2 = 8, V4 = 6, agent(V0), pos(V2), pos(V4), pos(V9).
terminal :- true_leaf(V2, V4), true_isplayer(V4, V8, V0), V0 = red, V2 = 8, V4 = 6, agent(V0), pos(V2), pos(V4), pos(V8).
terminal :- true_leaf(V8, V8), true_isplayer(V5, V8, V0), V5 = 5, V8 = 2, agent(V0), pos(V5), pos(V8).
terminal :- close(V8, V9), true_leaf(V3, V3), true_isplayer(V9, V8, V0), V3 = 7, V9 = 1, agent(V0), pos(V3), pos(V8), pos(V9).
terminal :- true_leaf(V8, V8), true_isplayer(V2, V6, V0), true_isplayer(V8, V2, V1), V6 = 4, agent(V0), agent(V1), pos(V2), pos(V6), pos(V8).
