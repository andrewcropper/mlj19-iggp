
legal(V0, V1) :- not dir(V1), agent(V0), action(V1).
legal(V0, V1) :- true_open(V10, V4), true_at(V4, V5, V9), true_at(V5, V5, V7), V1 = down, V4 = 3, agent(V0), action(V1), pos(V4), pos(V5), obj(V7), obj(V9), obj(V10).
legal(V0, V1) :- player_obj(V7), true_target(V3, V6), true_at(V6, V5, V7), V1 = right, agent(V0), action(V1), pos(V3), pos(V5), pos(V6), obj(V7).
legal(V0, V1) :- succ(V4, V2), player_obj(V7), true_target(V3, V6), true_at(V4, V3, V7), V1 = right, agent(V0), action(V1), pos(V2), pos(V3), pos(V4), pos(V6), obj(V7).
legal(V0, V1) :- succ(V2, V3), player_obj(V7), true_at(V3, V5, V10), true_at(V4, V3, V7), V1 = down, agent(V0), action(V1), pos(V2), pos(V3), pos(V4), pos(V5), obj(V7), obj(V10).
legal(V0, V1) :- succ(V2, V3), player_obj(V7), true_at(V2, V4, V8), true_at(V4, V3, V7), V1 = down, agent(V0), action(V1), pos(V2), pos(V3), pos(V4), obj(V7), obj(V8).
legal(V0, V1) :- door(V10), true_at(V3, V5, V10), true_at(V4, V3, V9), true_at(V5, V6, V7), V1 = left, agent(V0), action(V1), pos(V3), pos(V4), pos(V5), pos(V6), obj(V7), obj(V9), obj(V10).
legal(V0, V1) :- player_obj(V7), true_target(V3, V6), true_open(V10, V5), true_at(V5, V6, V7), V1 = right, agent(V0), action(V1), pos(V3), pos(V5), pos(V6), obj(V7), obj(V10).
legal(V0, V1) :- succ(V4, V2), true_open(V10, V5), true_at(V2, V4, V8), true_at(V4, V2, V9), V1 = left, agent(V0), action(V1), pos(V2), pos(V4), pos(V5), obj(V8), obj(V9), obj(V10).
legal(V0, V1) :- player_obj(V7), true_switch(V4, V5, V10), true_at(V5, V4, V7), agent(V0), action(V1), pos(V4), pos(V5), obj(V7), obj(V10).
legal(V0, V1) :- succ(V5, V4), player_obj(V7), true_target(V3, V6), true_at(V6, V4, V7), V1 = down, agent(V0), action(V1), pos(V3), pos(V4), pos(V5), pos(V6), obj(V7).
legal(V0, V1) :- player_obj(V7), true_at(V4, V6, V9), true_at(V5, V6, V7), V1 = left, V4 = 3, agent(V0), action(V1), pos(V4), pos(V5), pos(V6), obj(V7), obj(V9).
legal(V0, V1) :- succ(V6, V5), true_switch(V4, V5, V10), true_at(V5, V5, V7), true_at(V6, V4, V9), agent(V0), action(V1), pos(V4), pos(V5), pos(V6), obj(V7), obj(V9), obj(V10).
legal(V0, V1) :- succ(V5, V4), succ(V6, V5), true_at(V5, V4, V9), V1 = up, agent(V0), action(V1), pos(V4), pos(V5), pos(V6), obj(V9).
legal(V0, V1) :- succ(V4, V2), succ(V5, V4), player_obj(V7), true_at(V6, V5, V7), V1 = up, agent(V0), action(V1), pos(V2), pos(V4), pos(V5), pos(V6), obj(V7).
legal(V0, V1) :- is_box(V9), true_at(V4, V4, V9), true_at(V5, V2, V7), V2 = 4, V5 = 2, agent(V0), action(V1), pos(V2), pos(V4), pos(V5), obj(V7), obj(V9).
legal(V0, V1) :- true_target(V3, V6), true_open(V10, V2), true_at(V6, V2, V7), V1 = up, agent(V0), action(V1), pos(V2), pos(V3), pos(V6), obj(V7), obj(V10).
legal(V0, V1) :- true_switch(V4, V5, V10), true_at(V3, V5, V10), true_at(V4, V3, V9), true_at(V5, V6, V7), V1 = right, agent(V0), action(V1), pos(V3), pos(V4), pos(V5), pos(V6), obj(V7), obj(V9), obj(V10).
legal(V0, V1) :- succ(V6, V5), true_target(V3, V6), true_open(V10, V6), true_at(V5, V6, V7), V1 = right, agent(V0), action(V1), pos(V3), pos(V5), pos(V6), obj(V7), obj(V10).
legal(V0, V1) :- true_switch(V4, V5, V10), true_at(V5, V6, V7), true_at(V6, V4, V9), V1 = left, agent(V0), action(V1), pos(V4), pos(V5), pos(V6), obj(V7), obj(V9), obj(V10).
legal(V0, V1) :- succ(V6, V5), true_switch(V4, V5, V10), true_open(V10, V4), true_at(V6, V5, V9), V1 = right, agent(V0), action(V1), pos(V4), pos(V5), pos(V6), obj(V9), obj(V10).
