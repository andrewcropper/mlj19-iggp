
terminal :- true_step(V10), V10 = 20, int(V10).
terminal :- true_step(V15), V15 = 14, int(V15).
terminal :- true_step(V12), true_control(V20), true_cell(V22, V20), V12 = 17, V22 = e, int(V12), agent(V20), mark(V20), pos(V22).
terminal :- true_control(V21), true_cell(V25, V21), true_cell(V26, V21), V25 = b, V26 = a, agent(V21), mark(V21), pos(V25), pos(V26).
