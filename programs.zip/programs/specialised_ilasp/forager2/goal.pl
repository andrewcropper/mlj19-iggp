
goal(V0, V1) :- true_score(V1), agent(V0), int(V1).
