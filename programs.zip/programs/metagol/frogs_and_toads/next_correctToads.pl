
true.

% learning next_correctToads/2
% clauses: 1
% clauses: 2
% clauses: 3
