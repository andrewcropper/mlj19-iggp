
next_cell(V0, V1, V2) :- true_cell(V0, V1, V53), pos(V0), int(V0), pos(V1), int(V1), mark(V2), mark(V53).
