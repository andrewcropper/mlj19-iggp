
goal(V0, V1) :- true_claim_made_by(V22), V1 = 0, agent(V0), int(V1), agent(V22).
goal(V0, V1) :- true_score(V0, V1), true_gameOver, agent(V0), int(V1).
